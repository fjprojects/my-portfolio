# Additional certificates for Francis portfolio

These original-document images have been converted into optimized WebP files for the existing React/Vite portfolio.

The GitHub source `src/components/Certificates.jsx` is already updated and references all three paths below.

To finish displaying the real certificate images:
1. In GitHub, open the repository `fjprojects/my-portfolio`.
2. Upload these three images into `public/certificates/` (create the folders if necessary).
3. Keep the filenames exactly as listed. Render should redeploy from your main branch if auto-deploy is enabled.

Do not upload the README to the public folder unless you want to.

Files:
- public/certificates/agentic-ai-sprint.webp
- public/certificates/git-github-workshop.webp
- public/certificates/ai-conclave-hackathon.webp

Only the new certificates are included. Existing portfolio certificate assets remain unchanged.
